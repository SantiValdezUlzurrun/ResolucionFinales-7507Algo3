# Consignas

## Consigna 1

### Problemas de diseño

    * Se lanza una excepcion con un mensaje cuando deberia existir una clase dedicada
    a ese fin  que proveea mayor claridad.
    
    * Muchisimo codigo repetido en efectos.
    
### Principios violados

    * Single-Responsability porque a la hora de crear un efecto compuesto muy complejo no se esta
    delegando en los efectos mas simples.
