public class CadenaVaciaAlAplicarEfectoException extends RuntimeException {}
